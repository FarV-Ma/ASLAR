
> chmod +x CalibrateAngular.cfg
> chmod +x CalibrateLinear.cfg
> sh rbx1-prereq.sh

<img src="http://www.pirobot.org/images/rbx_thumbnail.png" align="left" hspace="10px">

This ROS metapackage provides sample code used in the book *ROS by Example* [available on Lulu.com](http://www.lulu.com/spotlight/pirobot).

Please use the [ROS By Example Google Group](https://groups.google.com/forum/#!forum/ros-by-example) to post questions.

The code in this branch is for **ROS Indigo**.

If you are still using ROS Hydro, please use the hydro-devel branch of this repository.

If you are still using ROS Groovy, please use the groovy-devel branch of this repository.

